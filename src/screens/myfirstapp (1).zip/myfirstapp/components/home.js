import React from 'react';
import {
  View,
  StyleSheet,
  Text,
  Image,
  SafeAreaView,
  ScrollView,
  FlatList,
  TouchableOpacity
} from 'react-native';

const Home = () => {
  const data = [
    {
      key: '1',
      image: './th.jpg',
      name: 'food1',
    },
    {
      key: '2',
      image: './image2.jpg',
      name: 'food2',
    },
    {
      key: '3',
      image: './th.jpg',
      name: 'food3',
    },
    {
      key: '4',
      image: './image2.jpg',
      name: 'food4',
    },
    {
      key: '5',
      image: './th.jpg',
      name: 'food5',
    },
    {
      key: '6',
      image: './image2.jpg',
      name: 'food6',
    },
  ];

  return (
    <ScrollView style={{ flex: 1, backgroundColor: 'white', padding: 40 }}>
      <View style={{ flex: 2, backgroundColor: '' }}>
        <Text>भोजन मंत्रालय</Text>
      </View>
      <View style={{ flex: 10, backgroundColor: '' }}>
       
        <FlatList
          // style={styles.card/}
          data={data}
          indexExtractor={(key) => {
            return key.id;
          }}
          
          showsHorizontalScrollIndicator={false}
          renderItem={({ item }) => {
            return (
              <TouchableOpacity
                style={styles.card}
               >
                <Image  
                  source="{item.image}"
                  style={{ width: 50, height: 50 }}
                  
                />
                <Text style={styles.txt}>"{item.image}"</Text>
              </TouchableOpacity>
            );
          }} 
        />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({

  card: {
   
    backgroundColor: '#D9D9D9',
    flex: 1,
    margin: 10,
    borderRadius: 10,
    // opacity: 0.3,
    justifyContent: 'center',
    // alignContent:'center',
    alignItems: 'center',
  },
});

export default Home;
