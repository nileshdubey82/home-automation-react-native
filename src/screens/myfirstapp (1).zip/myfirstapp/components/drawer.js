import React from "react";

import { createDrawerNavigator } from "@react-navigation/drawer";

import TabNavigator from "./bottomTab";
import Profile from './friendscreen';

const Drawer = createDrawerNavigator();

const DrawerNavigator = () => {
  return (
    <Drawer.Navigator screenOptions={{
    // drawerStyle: {
    //   backgroundColor: 'lightgreen',
    //   width: 240,
    // },
     headerStyle: {
          backgroundColor: '#009387',
        }, 
        headerTintColor: 'white',
  }} >
      <Drawer.Screen name="Welcome Alumni" component={TabNavigator} screenOptions={{
  
  }} />
      <Drawer.Screen name="Profile" component={Profile} />
    </Drawer.Navigator>
  );
}

export default DrawerNavigator; 