import React from 'react';
import {View, StyleSheet,Text} from 'react-native';

const Home = () => {


	return (
		<View style={{flex:1,backgroundColor:'white',padding:40}}>
      <View style={{flex:2, backgroundColor:''}}><Text>भोजन मंत्रालय</Text></View>
      <View style={{flex:10, backgroundColor:'black'}}></View>
		</View>
	);
}
 
const styles = StyleSheet.create({})

export default Home;

