import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

class FriendsScreen extends React.Component {
  render() {
    return (
      <View style={{flex:1}}>
        <Text>Addfriends here!</Text>
      </View>
    );
  }
}

// ...

export default FriendsScreen;