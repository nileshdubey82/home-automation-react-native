 import { createStackNavigator } from '@react-navigation/stack';
import Login from './login'
import Home from './home';
import FriendsScreen from './friendscreen';
import Bottom from "./bottomTab";
import Drawer from './drawer'
const Stack = createStackNavigator();

export default function MyStack() {
  return (
    <Stack.Navigator screenOptions={{
				headerStyle: {
					backgroundColor: '#2466A7FF',
				},
				headerTintColor: 'white',
			}}>
      <Stack.Screen name="FOODY" component={Bottom} options={{headerShown:false}} />
      <Stack.Screen name="Login" component={Login} options={{headerShown:false}} />
      <Stack.Screen name="FriendScreen" component={FriendsScreen} />
    </Stack.Navigator>
  ); 
}